﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BIBLIOTEKA_TESTOWANIE
{
    public partial class ZapominanieUżytkownika : Form
    {
        public ZapominanieUżytkownika()
        {
            InitializeComponent();
        }

        private void ZapominanieUżytkownika_Load(object sender, EventArgs e)
        {

        }
    }
}
