﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace BIBLIOTEKA_TESTOWANIE
{
    public partial class Form3 : Form
    { 

        private string connectionString = "Server=DESKTOP-N5NLODJ\\SQLEXPRESS;Database=TEsting;Integrated Security=True;TrustServerCertificate=True";
        private int edytowanyUzytkownikID = -1;
   
        public Form3()
        {
            InitializeComponent();
            WyswietlUzytkownikow();
            textBox1.TextChanged += textBox1_TextChanged; // Dodanie obsługi zdarzenia
        }

        private void WyswietlUzytkownikow()
        {
            var dt = DatabaseHelper.GetUzytkownicy(connectionString);
            dataGridViewUzytkownicy.DataSource = dt;
            dataGridViewUzytkownicy.Columns["ID_uzytkownik"].Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filterText = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(filterText))
            {
                WyswietlUzytkownikow();
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
            SELECT * FROM dbo.Uzytkownik
            WHERE Imie LIKE @filter OR Nazwisko LIKE @filter OR PESEL LIKE @filter OR Login_uzytkownika LIKE @filter";

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.SelectCommand.Parameters.AddWithValue("@filter", "%" + filterText + "%");

                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridViewUzytkownicy.DataSource = dt;
            }
        }



    }
}
